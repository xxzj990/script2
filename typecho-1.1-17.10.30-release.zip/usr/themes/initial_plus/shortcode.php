<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

//加载短代码
require_once __DIR__ . '/lib/shortcode.php';

//注册短代码toggle
function shortcode_toggle( $atts, $content = '' ){
	static $count = 0;
	$count++;
	$args = shortcode_atts( array('title' => '点击展开阅读更多内容','color' => '#666'), $atts );
	return '<div class="panel">
				<a data-toggle="collapse" href="#toggle-'.$count.'">
					<div class="panel-title iconfont icon-jiaodian icon-toggle-close" style="background-color:'.$args['color'].'">'.$args['title'].'</div>
				</a>
				<div id="toggle-'.$count.'" class="collapse">
					<div class="panel-body">'.$content.'</div>
				</div>
			</div>';
}
add_shortcode( 'toggle', 'shortcode_toggle' );

//注册短代码highlight
function shortcode_highlight( $atts, $content = '' ){
	$args = shortcode_atts( array('title' => '重要内容','color' => '#666'), $atts );
	return '<div class="highlight"><div class="highlight-title iconfont icon-highlight" style="background-color:'.$args['color'].'">&nbsp;'.$args['title'].'</div><div class="highlight-content">'.$content.'</div></div>';
}
add_shortcode( 'highlight', 'shortcode_highlight' );

//项目面板 注册短代码tips
function shortcode_panel_tips( $atts, $content = '' ) {
    return '<div class="tips mc-panel p-tips iconfont icon-tips clearfix">' . $content . '</div>';
}
add_shortcode( 'tips' , 'shortcode_panel_tips' );

//禁止面板 注册短代码noway
function shortcode_panel_noway( $atts, $content = '' ) {
    return '<div class="tips mc-panel p-noway iconfont icon-noway clearfix">' . $content . '</div>';
}
add_shortcode( 'noway' , 'shortcode_panel_noway' );

//警告面板 注册短代码warning
function shortcode_panel_warning( $atts, $content = '' ) {
    return '<div class="tips mc-panel p-warning iconfont icon-warning clearfix">' . $content . '</div>';
}
add_shortcode( 'warning' , 'shortcode_panel_warning' );

//购买面板 注册短代码buy
function shortcode_panel_buy( $atts, $content = '' ) {
    return '<div class="tips mc-panel p-buy iconfont icon-buy clearfix">' . $content . '</div>';
}
add_shortcode( 'buy' , 'shortcode_panel_buy' );

//下载面板 注册短代码note
function shortcode_panel_note( $atts, $content = '' ) {
    return '<div class="tips mc-panel p-note iconfont icon-note clearfix">' . $content . '</div>';
}
add_shortcode( 'note' , 'shortcode_panel_note' );

//下载面板 注册短代码ref
function shortcode_panel_ref( $atts, $content = '' ) {
    return '<div class="tips mc-panel p-ref iconfont icon-link clearfix">' . $content . '</div>';
}
add_shortcode( 'ref' , 'shortcode_panel_ref' );

//打赏按钮 注册短码likeme
function shortcode_likeme_button( $atts, $content= ''){
	$options = Typecho_Widget::widget('Widget_Options');
	static $count = 0;
	$count++;
	if($options->WeChat && $options->Alipay) { return '
<button class="likeme-bnt iconfont icon-dianzan" data-toggle="modal" data-target="#likeme-'.$count.'">'. $content .'</button><div class="modal fade" id="likeme-'.$count.'" tabindex="-1" role="dialog"><div class="modal-dialog"><div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><span class="modal-title iconfont icon-saoyisao">&nbsp;赞赏作者</span></div><div class="tab-content"><div class="tab-pane fade in active" id="like-wechat-qr-'.$count.'"><img src="'.$options->WeChat.'" alt="微信收款二维码" /></div><div class="tab-pane fade" id="like-ali-qr-'.$count.'"><img src="'.$options->Alipay.'" alt="支付宝收款二维码" /></div></div><div class="modal-footer"><a href="#like-wechat-qr-'.$count.'" data-toggle="tab"><button type="button" class="like-bnt-wechat">微信</button></a><a href="#like-ali-qr-'.$count.'" data-toggle="tab"><button type="button" class="like-bnt-ali">支付宝</button></a></div></div></div>';
	} elseif ($options->WeChat) { return '
<button class="likeme-bnt iconfont icon-dianzan" data-toggle="modal" data-target="#likeme-'.$count.'">'. $content .'</button><div class="modal fade" id="likeme-'.$count.'" tabindex="-1" role="dialog"><div class="modal-dialog"><div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><span class="modal-title iconfont icon-saoyisao">&nbsp;赞赏作者</span></div><div class="tab-content"><div class="tab-pane fade in active" id="like-wechat-qr-'.$count.'"><img src="'.$options->WeChat.'" alt="微信收款二维码" /></div></div><div class="modal-footer"><a href="#like-wechat-qr-'.$count.'" data-toggle="tab"><button type="button" class="like-bnt-wechat">微信</button></a></div></div></div>';
	} elseif ($options->Alipay) { return '
<button class="likeme-bnt iconfont icon-dianzan" data-toggle="modal" data-target="#likeme-'.$count.'">'. $content .'</button><div class="modal fade" id="likeme-'.$count.'" tabindex="-1" role="dialog"><div class="modal-dialog"><div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><span class="modal-title iconfont icon-saoyisao">&nbsp;赞赏作者</span></div><div class="tab-content"><div class="tab-pane fade in active" id="like-ali-qr-'.$count.'"><img src="'.$options->Alipay.'" alt="支付宝收款二维码" /></div></div><div class="modal-footer"><a href="#like-ali-qr-'.$count.'" data-toggle="tab"><button type="button" class="like-bnt-ali">支付宝</button></a></div></div></div>';
	} else { return '<strong style="color:red">请在主题设置中填入打赏二维码链接！</strong>'; }
}
add_shortcode('likeme','shortcode_likeme_button');

//焦点按钮 注册短码focus
function shortcode_focus_button( $atts, $content= ''){
	static $count = 0;
	$count++;
	$args = shortcode_atts( array('title' => '焦点内容','color' => '#666','name' => '点击查看焦点内容'), $atts );
	return '<button class="focus-bnt iconfont icon-jiaodian" style="background-color:'.$args['color'].'" data-toggle="modal" data-target="#focus-'.$count.'">'.$args['name'].'</button><div class="modal fade focus" id="focus-'.$count.'" tabindex="-1" role="dialog"><div class="modal-dialog"><div class="modal-header" style="background-color:'.$args['color'].'"><button type="button" class="close" data-dismiss="modal">&times;</button><span class="modal-title iconfont icon-jujiao">&nbsp;'.$args['title'].'</span></div><div class="focus-content">'.$content.'</div><div class="modal-footer"><button type="button" class="focus-bnt-close" style="background-color:'.$args['color'].'" data-dismiss="modal">关闭</button></div></div></div>';
}
add_shortcode('focus','shortcode_focus_button');

//下载按钮 注册短码down
function shortcode_down_button( $atts, $content = '' ){
	$args = shortcode_atts( array('url' => Typecho_Widget::widget('Widget_Options')->siteUrl,'color' => '#38a3fd','blank' => 1), $atts );
	if($args['blank']) {
		return '<button class="xiazai-bnt iconfont icon-down" style="background-color:'.$args['color'].'" onclick="window.open(&quot;'.$args['url'].'&quot;,&quot;_blank&quot;)">'.$content.'</button>';
	} else {
		return '<a href="'.$args['url'].'"><button class="xiazai-bnt iconfont icon-down" style="background-color:'.$args['color'].'">'.$content.'</button></a>';
	}
}
add_shortcode( 'down', 'shortcode_down_button' );

//链接按钮 注册短码link
function shortcode_link_button( $atts, $content = '' ){
	$args = shortcode_atts( array('url' => Typecho_Widget::widget('Widget_Options')->siteUrl,'color' => '#9f9f9f','blank' => 1), $atts );
	if($args['blank']) {
		return '<button class="xiazai-bnt iconfont icon-link" style="background-color:'.$args['color'].'" onclick="window.open(&quot;'.$args['url'].'&quot;,&quot;_blank&quot;)">'.$content.'</button>';
	} else {
		return '<a href="'.$args['url'].'"><button class="xiazai-bnt iconfont icon-link" style="background-color:'.$args['color'].'">'.$content.'</button></a>';
	}
}
add_shortcode( 'link', 'shortcode_link_button' );

//购物按钮 注册短码shop
function shortcode_shop_button( $atts, $content = '' ){
	$args = shortcode_atts( array('url' => Typecho_Widget::widget('Widget_Options')->siteUrl,'color' => '#ff4400','blank' => 1), $atts );
	if($args['blank']) {
		return '<button class="xiazai-bnt iconfont icon-shop" style="background-color:'.$args['color'].'" onclick="window.open(&quot;'.$args['url'].'&quot;,&quot;_blank&quot;)">'.$content.'</button>';
	} else {
		return '<a href="'.$args['url'].'"><button class="xiazai-bnt iconfont icon-shop" style="background-color:'.$args['color'].'">'.$content.'</button></a>';
	}
}
add_shortcode( 'shop', 'shortcode_shop_button' );

//隔壁按钮 注册短码github
function shortcode_github_button( $atts, $content = '' ){
	$args = shortcode_atts( array('url' => Typecho_Widget::widget('Widget_Options')->siteUrl,'color' => '#363a3e','blank' => 1), $atts );
	if($args['blank']) {
		return '<button class="xiazai-bnt iconfont icon-github" style="background-color:'.$args['color'].'" onclick="window.open(&quot;'.$args['url'].'&quot;,&quot;_blank&quot;)">'.$content.'</button>';
	} else {
		return '<a href="'.$args['url'].'"><button class="xiazai-bnt iconfont icon-github" style="background-color:'.$args['color'].'">'.$content.'</button></a>';
	}
}
add_shortcode( 'github', 'shortcode_github_button' );

//Steam按钮 注册短码steam
function shortcode_steam_button( $atts, $content = '' ){
	$args = shortcode_atts( array('url' => Typecho_Widget::widget('Widget_Options')->siteUrl,'color' => '#1b2838','blank' => 1), $atts );
	if($args['blank']) {
		return '<button class="xiazai-bnt iconfont icon-steam" style="background-color:'.$args['color'].'" onclick="window.open(&quot;'.$args['url'].'&quot;,&quot;_blank&quot;)">'.$content.'</button>';
	} else {
		return '<a href="'.$args['url'].'"><button class="xiazai-bnt iconfont icon-steam" style="background-color:'.$args['color'].'">'.$content.'</button></a>';
	}
}
add_shortcode( 'steam', 'shortcode_steam_button' );
