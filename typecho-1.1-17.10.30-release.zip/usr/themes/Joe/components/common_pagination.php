<?php $this->pageNav(
    '上一页',
    '下一页',
    1,
    '...',
    array(
        'wrapTag' => 'ul',
        'wrapClass' => 'joe-pagination',
        'itemTag' => 'li',
        'textTag' => 'a',
        'currentClass' => 'active',
        'prevClass' => 'prev',
        'nextClass' => 'next'
    )
);
