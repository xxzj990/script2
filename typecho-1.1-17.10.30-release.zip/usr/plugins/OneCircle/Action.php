<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * OneCircle
 *
 * @package OneCircle
 * @author gogobody
 * @version 2.0.0
 * @link https://blog.gogobody.cn
 */
class OneCircle_Action extends Widget_Abstract_Contents implements Widget_Interface_Do
{
    public function __construct($request, $response, $params = NULL) {
        parent::__construct($request, $response, $params);
    }

    public function execute()
    {
        //Do nothing
    }

    // do /oneaction  apis
    public function route()
    {
        $request = Typecho_Request::getInstance();
        $type = $request->get('type');
        switch ($type) {
            // 用于link 解析
            case "parsemeta":
                $url = $request->get('url');
                $html = $this->getUrlContent($url);
                print_r($this->getDescriptionFromContent($html, 120));
                break;
            // 用于主页前台发布
            case "getsecuritytoken":
                if ($request->isPost()){

                    $security = $this->widget('Widget_Security');
                    echo $security->getToken($this->request->getReferer());
                    break;

                }
                echo 'error';
                break;
            // get login action   <?php $this
            // 用于登录
            case "getsecurl":
                if ($request->isPost()){
                    $url = $request->get('url');
                    $path = Typecho_Router::url('do', array('action' => 'login', 'widget' => 'Login'),
                        Typecho_Common::url('index.php', $this->rootUrl));
                    echo $this->getTokenUrl($path,$url);
                    break;
                }
                echo 'error';
                break;
            case "getfocusmid":
                if ($request->isPost()){
                    echo Typecho_Widget::widget('Widget_Options')->plugin('OneCircle')->focususerMid;
                    break;
                }
                echo "error method";
                break;
            default:
                echo 'unhandled method';
                break;
        }

    }


    // 解析网页内容
    function getUrlContent($url, $ecms = 0, $post = 0)
    {
        $header = array(
            'User-Agent: Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.146 Safari/537.36'
        );
        $ch = curl_init();
        $timeout = 15;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // 伪造百度蜘蛛头部
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, $ecms);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POST, $post);
        // 执行
        $content = curl_exec($ch);
        if ($content == FALSE) {
            echo "error:" . curl_error($ch);
        }
        // 关闭
        curl_close($ch);
        //输出结果
        return $content;
    }

    // 获取描述
    function getDescriptionFromContent($content, $count)
    {
        preg_match("/<title>(.*?)<\/title>/s",$content, $title);
        if(count($title) == 0){
            preg_match('/<meta +name *=["\']?description["\']? *content=["\']?([^<>"]+)["\']?/i', $content, $res);
            if(count($res) == 0){ //match failed
                $content = preg_replace("@<script(.*?)</script>@is", "", $content);
                $content = preg_replace("@<iframe(.*?)</iframe>@is", "", $content);
                $content = preg_replace("@<style(.*?)</style>@is", "", $content);
                $content = preg_replace("@<(.*?)>@is", "", $content);
                $content = str_replace(PHP_EOL, '', $content);
                $space = array(" ", "　", "  ", " ", " ","\t","\n","\r");
                $go_away = array("", "", "", "", "","","","");
                $content = str_replace($space, $go_away, $content);
            }else{ //match success
                $content = $res[1];
            }
        }else {
            $content = $title[1];
        }
        $content = trim($content);

        $res = mb_substr($content, 0, $count, 'UTF-8');
        if (mb_strlen($content, 'UTF-8') > $count) {
            $res = $res . "...";
        }
        return $res;
    }

    /**
     * 生成带token的路径
     *
     * @param $path
     * @param $url
     * @return string
     * @throws Typecho_Exception
     */
    function getTokenUrl($path,$url)
    {
        $parts = parse_url($path);
        $params = array();

        if (!empty($parts['query'])) {
            parse_str($parts['query'], $params);
        }
        $security = $this->widget('Widget_Security');
        if ($url){
            $requrl = $url;
        }else
            $requrl = $this->request->getRequestUrl();
        $params['_'] = $security->getToken($requrl);
        $parts['query'] = http_build_query($params);

        return Typecho_Common::buildUrl($parts);
    }

    // do /action/oneapi apis
    public function action()
    {

    }


}

