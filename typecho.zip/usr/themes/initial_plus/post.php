<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<div id="main">
<div class="post-biaoti">
<h1 class="post-title"><?php if ($this->fields->original == 1): ?><span class="original" title="作者原创">原创</span><?php endif; ?><?php $this->title() ?></h1>
<ul class="post-meta">
<?php if ($this->options->isauthor): ?><li class="iconfont icon-wo" title="作者">&nbsp;<a href="<?php $this->author->permalink(); ?>"><?php $this->author(); ?></a></li><?php endif; ?>
<li class="iconfont icon-rili" title="发布日期">&nbsp;<?php $this->date(); ?></li>
<li class="iconfont icon-fenlei" title="文章分类">&nbsp;<?php $this->category(','); ?></li>
<?php if($this->allow('comment')): ?>
<li class="iconfont icon-pinglun" title="文章评论">&nbsp;<a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('暂无', '%d'); ?></a></li>
<?php else: ?>
<li class="iconfont icon-pinglun" title="评论关闭">&nbsp;关闭</li>
<?php endif; ?>
<li class="iconfont icon-yanjing" title="文章阅读">&nbsp;<?php Postviews($this); ?></li>
</ul>
</div>
<?php if (!empty($this->options->Breadcrumbs) && in_array('Postshow', $this->options->Breadcrumbs)): ?>
<div class="breadcrumbs post-mianbao iconfont icon-shouye">
<a href="<?php $this->options->siteUrl(); ?>">返回首页</a> &raquo; <?php $this->category(); ?> &raquo; <?php if (!empty($this->options->Breadcrumbs) && in_array('Text', $this->options->Breadcrumbs)): ?>正文<?php else: $this->title(); endif; ?>
</div>
<?php endif; ?>
<article class="post<?php if ($this->options->PjaxOption && $this->hidden): ?> protected<?php endif; ?> post-zhengwen">
<?php if (postThumb($this)): ?>
<div class="thumb post-toutu"><?php echo postThumb($this); ?></div>
<?php endif; ?>
<div class="post-wenzhang">
<div class="post-content">
<?php echo parseContent($this); ?>
</div>
<li id="like">
<?php if ($this->options->WeChat || $this->options->Alipay): ?>
<button class="like-bnt iconfont icon-dianzan" data-toggle="modal" data-target="#likeme">&nbsp;赞赏</button>
<div class="modal fade" id="likeme" tabindex="-1" role="dialog">
<div class="modal-dialog">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<span class="modal-title iconfont icon-saoyisao">&nbsp;赞赏作者</span>
</div>
<div class="tab-content">
<?php if ($this->options->WeChat): ?>
<div class="tab-pane fade in active" id="like-wechat-qr">
<img src="<?php $this->options->WeChat(); ?>" alt="微信收款二维码" />
</div><?php endif; ?>
<?php if ($this->options->Alipay): ?>
<div class="tab-pane fade<?php if (!$this->options->WeChat): ?>  in active<?php endif; ?>" id="like-ali-qr">
<img src="<?php $this->options->Alipay(); ?>" alt="支付宝收款二维码" />
</div><?php endif; ?>
</div>
<div class="modal-footer">
<?php if ($this->options->WeChat): ?><a href="#like-wechat-qr" data-toggle="tab"><button type="button" class="like-bnt-wechat">微信</button></a><?php endif; ?>
<?php if ($this->options->Alipay): ?><a href="#like-ali-qr" data-toggle="tab"><button type="button" class="like-bnt-ali">支付宝</button></a><?php endif; ?>
</div>
</div>
</div>
<?php endif; ?>
</li>
<li id="theend">- The end! -</li>
<?php if ($this->fields->original && $this->fields->original != 1): ?><p class="tags iconfont icon-zhuanzai">&nbsp;转载: <a href="###" onclick="window.open('<?php $this->fields->original(); ?>','_blank')">原文链接</a></p><?php endif; ?>
<p class="tags iconfont icon-biaoqian">&nbsp;标签: <?php $this->tags(', ', true, 'none'); ?></p>
<p class="license"><?php echo $this->options->LicenseInfo ? $this->options->LicenseInfo : '本作品采用 <a rel="license nofollow" href="https://creativecommons.org/licenses/by-sa/4.0/" target="_blank">知识共享署名-相同方式共享 4.0 国际许可协议</a> 进行许可。' ?></p>
</div>
</article>
<?php $this->need('comments.php'); ?>
<ul class="post-near">
<li>上一篇: <?php $this->thePrev('%s','没有了'); ?></li>
<li>下一篇: <?php $this->theNext('%s','没有了'); ?></li>
</ul>
</div>
<?php $this->need('sidebar.php'); ?>
<?php $this->need('footer.php'); ?>