<?php

class NginxLog {
    protected $fileName = '';
    protected $size = 0;  //  流量消耗
    protected $google = 0;  //  Google爬虫
    protected $baidu = 0;  //  百度爬虫
    protected $sogou = 0;  //  搜狗爬虫
    protected $bing = 0;  //  必应爬虫
    protected $s360 = 0;  //  360爬虫
    protected $shenma = 0;  //  神马搜索
    protected $toutiao = 0;  //  头条爬虫
    protected $http404 = 0;  //  404统计
    protected $http200 = 0;  //  200成功
    protected $http301 = 0;  //  301统计
    protected $ahrefsBot = 0;  //  AhrefsBot爬虫
    protected $semrushBot = 0;  //  SemrushBot爬虫
    protected $errorResult = array(
        'http' => 0,
        'size' => 0,
        'google' => 0,
        'baidu' => 0,
        'sougou' => 0,
        's360' => 0,
        'bing' => 0,
        'shenma' => 0,
        'toutiao' => 0,
        'ahrefsBot' => 0,
        'semrushBot' => 0,
        'http404' => 0,
        'http200' => 0,
        'http301' => 0
    );
    protected $pdo;

    public function __construct($name) {
        $this->fileName = $name;
    }

    //  获取文章时间
    public function postData($start, $end) {
        if (!is_object($this->pdo)) {
            if (!$this->connectDB()) {
                return array();
            }
        }

        $sql = "SELECT created FROM typecho_contents WHERE created > {$start} AND created < {$end} AND type = 'post'";
        $data = $this->pdo->query($sql);
        if ($data->rowCount() < 1) {
            return array();
        }
        $data = $data->fetchAll();
        $dataArr = array();
        foreach ($data as $val) {
            array_push($dataArr, date('Y-m-d', $val['created']));
        }
        $dataArr = array_count_values($dataArr);
        $key = array_keys($dataArr);
        $data = array();
        for ($i = 0;$i < count($dataArr);$i ++) {
            array_push($data, array(
                $key[$i],
                $dataArr[$key[$i]]
            ));
        }
        return $data;
    }

    //  获取评论时间
    public function commentDate($start, $end) {
        if (!is_object($this->pdo)) {
            if (!$this->connectDB()) {
                return array();
            }
        }

        $sql = "SELECT created FROM typecho_comments WHERE created > {$start} AND created < {$end}";
        $data = $this->pdo->query($sql);
        if ($data->rowCount() < 1) {
            return array();
        }
        $data = $data->fetchAll();
        $dataArr = array();
        foreach ($data as $val) {
            array_push($dataArr, date('Y-m-d', $val['created']));
        }
        $dataArr = array_count_values($dataArr);
        $key = array_keys($dataArr);
        $data = array();
        for ($i = 0;$i < count($dataArr);$i ++) {
            array_push($data, array(
                $key[$i],
                $dataArr[$key[$i]]
            ));
        }
        return $data;
    }

    protected function connectDB() {
        $DB_TYPE = 'mysql';
        $DB_SERVER = '127.0.0.1';
        $DB_NAME = 'typecho';
        $DB_USER = 'root';
        $DB_PASSWORD = 'machangbin';

        $dsn = $DB_TYPE . ':host=' . $DB_SERVER . ';dbname=' . $DB_NAME;

        try {
            $this->pdo = new PDO($dsn, $DB_USER, $DB_PASSWORD);
            $this->pdo->query("set names utf8");
            return true;
        }catch (PDOexception $e) {
            $this->db_error = $e->getMessage();
            return false;
        }
    }

    //  获取数据
    public function getData() {
        $googleUA = '/\+http\:\/\/www\.google\.com\/bot|Googlebot/';
        $sogouUA = '/\+http\:\/\/www\.sogou\.com\/docs\/help|Sogou web spider/';
        $baiduUA = '/\+http\:\/\/www\.baidu\.com\/search\/spider|Baiduspider/';
        $bingUA = '/\+http\:\/\/www\.bing\.com\/bingbot|bingbot/';
        $s360UA = '/360Spider/';
        $shenmaUA = '/YisouSpider/';
        $toutiaoUA = '/Bytespider/';
        $ahrefsBotUA = '/AhrefsBot/';
        $semrushBotUA = '/SemrushBot/';

        if (!file_exists($this->fileName)) {
            return $this->errorResult;
        }

        $file = file_get_contents($this->fileName);  //  读取文件

        if ($file == '') {
            return $this->errorResult;
        }

        $arr = explode("\n", $file);  //  行分割
        foreach ($arr as $val) {
            $log = explode(' ', $val);
            for ($i = 0;$i < count($log);$i ++) {
                //  流量消耗统计
                if ($log[$i] == '200' or $log[$i] == '301' or $log[$i] == '404') {
                    $this->size = $this->size + $log[$i + 1];
                }
            }
            //  Google爬虫统计
            preg_match($googleUA, $val, $googleResult);
            if (is_array($googleResult) && count($googleResult)) {
                $this->google = $this->google + 1;
            }
            //  搜狗爬虫统计
            preg_match($sogouUA, $val, $sogouResult);
            if (is_array($sogouResult) && count($sogouResult)) {
                $this->sogou = $this->sogou + 1;
            }
            //  百度爬虫统计
            preg_match($baiduUA, $val, $baiduResult);
            if (is_array($baiduResult) && count($baiduResult)) {
                $this->baidu = $this->baidu + 1;
            }
            //  必应爬虫统计
            preg_match($bingUA, $val, $bingResult);
            if (is_array($bingResult) && count($bingResult)) {
                $this->bing = $this->bing + 1;
            }
            //  360爬虫
            preg_match($s360UA, $val, $s360Result);
            if (is_array($s360Result) && count($s360Result)) {
                $this->s360 = $this->s360 + 1;
            }
            //  神马搜索爬虫统计
            preg_match($shenmaUA, $val, $shengmaResult);
            if (is_array($shengmaResult) && count($shengmaResult)) {
                $this->shenma = $this->shenma + 1;
            }
            //  头条搜索爬虫统计
            preg_match($toutiaoUA, $val, $toutiaoResult);
            if (is_array($toutiaoResult) && count($toutiaoResult)) {
                $this->toutiao = $this->toutiao + 1;
            }
            //  404统计
            preg_match('/ 404 /', $val, $http404Result);
            if (is_array($http404Result) && count($http404Result)) {
                $this->http404 = $this->http404 + 1;
            }
            //  200统计
            preg_match('/ 200 /', $val, $http200Result);
            if (is_array($http200Result) && count($http200Result)) {
                $this->http200 = $this->http200 + 1;
            }
            //  301统计
            preg_match('/ 301 /', $val, $http301Result);
            if (is_array($http301Result) && count($http301Result)) {
                $this->http301 = $this->http301 + 1;
            }
            //  ahrefsBot爬虫统计
            preg_match($ahrefsBotUA, $val, $ahrefsBotResult);
            if (is_array($ahrefsBotResult) && count($ahrefsBotResult)) {
                $this->ahrefsBot = $this->ahrefsBot + 1;
            }
            //  semrushBot爬虫统计
            preg_match($semrushBotUA, $val, $semrushBotResult);
            if (is_array($semrushBotResult) && count($semrushBotResult)) {
                $this->semrushBot = $this->semrushBot + 1;
            }
        }

        return array(
            'http' => count($arr),
            'size' => $this->byteFormat($this->size),
            'google' => $this->google,
            'baidu' => $this->baidu,
            'sougou' => $this->sogou,
            's360' => $this->s360,
            'bing' => $this->bing,
            'shenma' => $this->shenma,
            'toutiao' => $this->toutiao,
            'ahrefsBot' => $this->ahrefsBot,
            'semrushBot' => $this->semrushBot,
            'http404' => $this->http404,
            'http200' => $this->http200,
            'http301' => $this->http301
        );
    }

    //  流量格式化
    public function byteFormat($byte = 0) {
        if ($byte < 1024) {
            return $byte . '字节';
        }else if ($byte > 1024 && $byte < 1048576) {
            return round($byte / 1024, 1) . 'KB';
        }else if ($byte > 1048576 && $byte < 1073741824) {
            return round($byte / 1024 / 1024, 1) . 'MB';
        }else {
            return round($byte / 1024 / 1024 / 1024, 1) . 'GB';
        }
    }

    //  清空日志
    public function deleteLog() {
        if (!file_exists($this->fileName)) {
            return false;
        }
        file_put_contents($this->fileName, '');
    }

    //  分割日志
    public function copyLog($path) {
        if (!file_exists($this->fileName)) {
            return false;
        }
        $content = file_get_contents($this->fileName);
        preg_match('/\/$/', $path, $result);
        if (!is_array($result) or !count($result)) {
            $path = $path . '/';
        }
        $newFileName = $path . date('Y-m-d', time() - 3600) . '.log';
        if (file_exists($newFileName)) {
            $newFileName = $path . date('Y-m-d', time() + 3600 * 24) . '.log';
        }
        $file = fopen($newFileName, 'w');
        if (!fwrite($file, $content)) {
            return false;
        }
        fclose($file);
        $this->deleteLog();
        return true;
    }
}