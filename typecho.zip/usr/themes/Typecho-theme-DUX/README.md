# Typecho-theme-DUX

>Forked from https://coding.net/u/Arco-X/p/DUX-for-Typecho/git

一款基于大前端DUX for Wordpress主题修改而来的主题。

# 特性
- 修复了原版不能正常评论的问题
- 美化了样式，修改细节
- 增加了一些小功能

# 预览地址
https://blog.hicasper.com

![Typecho-theme-DUX.png](https://i.loli.net/2020/06/12/UXLK3a8SuVcxi2W.png)

# 赞助作者
如果觉得此作品对你有帮助，可以打赏一下作者，感谢您的帮助！

[![](https://i.loli.net/2020/06/12/udQD8TMfbRYmH1I.png)](https://www.hicasper.com/pay/)

>本主题仅基于爱好修改，使用时请尊重原作者大前端版权。
